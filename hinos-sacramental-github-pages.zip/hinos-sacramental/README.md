# Hinos da Reunião Sacramental

Página simples em HTML/CSS com os quatro hinos da reunião e links para as páginas oficiais da Igreja.

## Publicar com GitHub Pages

1. Crie um repositório público chamado `hinos-sacramental`.
2. Envie o arquivo `index.html` para a raiz do repositório.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/(root)`, depois clique em **Save**.
6. Aguarde a publicação. O endereço normalmente será:
   `https://angolodev-ctrl.github.io/hinos-sacramental/`

Confirme que o endereço abre antes de gerar e imprimir o QR Code definitivo.
